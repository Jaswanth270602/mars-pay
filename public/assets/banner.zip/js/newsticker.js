$(function(e){
  'use strict' 
  
	$('.js-conveyor-example').jConveyorTicker({reverse_elm: true});

});